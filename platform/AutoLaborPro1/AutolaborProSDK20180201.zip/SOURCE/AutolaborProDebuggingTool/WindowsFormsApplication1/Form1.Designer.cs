﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.Common;  
using System.IO.Ports;
using System.Threading;

namespace WindowsFormsApplication1
{
    partial class Form1
    {
        DataTable dt = new DataTable();  
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.receive_textBox = new System.Windows.Forms.TextBox();
            this.sendData_button = new System.Windows.Forms.Button();
            this.init_button = new System.Windows.Forms.Button();
            this.databits_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.send_textBox = new System.Windows.Forms.TextBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.portname_comboBox = new System.Windows.Forms.ComboBox();
            this.parity_comboBox = new System.Windows.Forms.ComboBox();
            this.stopbit_comboBox = new System.Windows.Forms.ComboBox();
            this.handshake_comboBox = new System.Windows.Forms.ComboBox();
            this.baudrate_textBox = new System.Windows.Forms.TextBox();
            this.clearText_button = new System.Windows.Forms.Button();
            this.decode_button = new System.Windows.Forms.Button();
            this.initSet_groupBox = new System.Windows.Forms.GroupBox();
            this.ticksPerRound_textBox = new System.Windows.Forms.TextBox();
            this.MaxVel_textBox9 = new System.Windows.Forms.TextBox();
            this.PIDrate_textBox = new System.Windows.Forms.TextBox();
            this.wheelDiameter_textBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.velControl_groupBox = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.reset_button = new System.Windows.Forms.Button();
            this.goBack_button = new System.Windows.Forms.Button();
            this.goAhead_button = new System.Windows.Forms.Button();
            this.goLeft_button = new System.Windows.Forms.Button();
            this.goRight_button = new System.Windows.Forms.Button();
            this.sendSpeed_button = new System.Windows.Forms.Button();
            this.RSpeed_textBox = new System.Windows.Forms.TextBox();
            this.LSpeed_textBox = new System.Windows.Forms.TextBox();
            this.RDistanceLabel = new System.Windows.Forms.Label();
            this.LDistanceLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.statusWatch_groupBox = new System.Windows.Forms.GroupBox();
            this.batteryReq_button = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.battery_label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.dataWatch_groupBox = new System.Windows.Forms.GroupBox();
            this.clearEncoderButton = new System.Windows.Forms.Button();
            this.initSet_groupBox.SuspendLayout();
            this.velControl_groupBox.SuspendLayout();
            this.statusWatch_groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.dataWatch_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // receive_textBox
            // 
            this.receive_textBox.Location = new System.Drawing.Point(13, 20);
            this.receive_textBox.Multiline = true;
            this.receive_textBox.Name = "receive_textBox";
            this.receive_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.receive_textBox.Size = new System.Drawing.Size(245, 85);
            this.receive_textBox.TabIndex = 1;
            // 
            // sendData_button
            // 
            this.sendData_button.Location = new System.Drawing.Point(511, 108);
            this.sendData_button.Name = "sendData_button";
            this.sendData_button.Size = new System.Drawing.Size(75, 23);
            this.sendData_button.TabIndex = 3;
            this.sendData_button.Text = "发送";
            this.sendData_button.UseVisualStyleBackColor = true;
            this.sendData_button.Click += new System.EventHandler(this.sendData_button_Click);
            // 
            // init_button
            // 
            this.init_button.Location = new System.Drawing.Point(26, 248);
            this.init_button.Name = "init_button";
            this.init_button.Size = new System.Drawing.Size(75, 23);
            this.init_button.TabIndex = 4;
            this.init_button.Text = "初始化";
            this.init_button.UseVisualStyleBackColor = true;
            this.init_button.Click += new System.EventHandler(this.init_button_Click);
            // 
            // databits_textBox
            // 
            this.databits_textBox.Location = new System.Drawing.Point(216, 49);
            this.databits_textBox.Name = "databits_textBox";
            this.databits_textBox.Size = new System.Drawing.Size(46, 21);
            this.databits_textBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "端口名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "波特率：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 11;
            this.label3.Text = "校验：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(146, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "数据位：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(146, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "握手协议：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "停止位：";
            // 
            // send_textBox
            // 
            this.send_textBox.Location = new System.Drawing.Point(338, 20);
            this.send_textBox.Multiline = true;
            this.send_textBox.Name = "send_textBox";
            this.send_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.send_textBox.Size = new System.Drawing.Size(245, 82);
            this.send_textBox.TabIndex = 17;
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(161, 248);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(75, 23);
            this.exit_button.TabIndex = 18;
            this.exit_button.Text = "退出程序";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // portname_comboBox
            // 
            this.portname_comboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.portname_comboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.portname_comboBox.FormattingEnabled = true;
            this.portname_comboBox.Items.AddRange(new object[] {
            "COM7",
            "COM8",
            "COM11",
            "COM1",
            "COM2",
            "COM4",
            "COM3"});
            this.portname_comboBox.Location = new System.Drawing.Point(94, 16);
            this.portname_comboBox.Name = "portname_comboBox";
            this.portname_comboBox.Size = new System.Drawing.Size(46, 20);
            this.portname_comboBox.TabIndex = 19;
            // 
            // parity_comboBox
            // 
            this.parity_comboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.parity_comboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.parity_comboBox.FormattingEnabled = true;
            this.parity_comboBox.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.parity_comboBox.Location = new System.Drawing.Point(94, 50);
            this.parity_comboBox.Name = "parity_comboBox";
            this.parity_comboBox.Size = new System.Drawing.Size(46, 20);
            this.parity_comboBox.TabIndex = 20;
            // 
            // stopbit_comboBox
            // 
            this.stopbit_comboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.stopbit_comboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.stopbit_comboBox.FormattingEnabled = true;
            this.stopbit_comboBox.Items.AddRange(new object[] {
            "None",
            "One",
            "Two",
            "OnePointFive"});
            this.stopbit_comboBox.Location = new System.Drawing.Point(94, 82);
            this.stopbit_comboBox.Name = "stopbit_comboBox";
            this.stopbit_comboBox.Size = new System.Drawing.Size(46, 20);
            this.stopbit_comboBox.TabIndex = 21;
            // 
            // handshake_comboBox
            // 
            this.handshake_comboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.handshake_comboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.handshake_comboBox.FormattingEnabled = true;
            this.handshake_comboBox.Items.AddRange(new object[] {
            "None",
            "XOnXOff",
            "RequestToSend",
            "RequestToSendXOnXOff"});
            this.handshake_comboBox.Location = new System.Drawing.Point(216, 82);
            this.handshake_comboBox.Name = "handshake_comboBox";
            this.handshake_comboBox.Size = new System.Drawing.Size(46, 20);
            this.handshake_comboBox.TabIndex = 22;
            // 
            // baudrate_textBox
            // 
            this.baudrate_textBox.Location = new System.Drawing.Point(216, 16);
            this.baudrate_textBox.Name = "baudrate_textBox";
            this.baudrate_textBox.Size = new System.Drawing.Size(46, 21);
            this.baudrate_textBox.TabIndex = 7;
            // 
            // clearText_button
            // 
            this.clearText_button.Location = new System.Drawing.Point(348, 108);
            this.clearText_button.Name = "clearText_button";
            this.clearText_button.Size = new System.Drawing.Size(75, 23);
            this.clearText_button.TabIndex = 23;
            this.clearText_button.Text = "清空";
            this.clearText_button.UseVisualStyleBackColor = true;
            this.clearText_button.Click += new System.EventHandler(this.clearText_button_Click);
            // 
            // decode_button
            // 
            this.decode_button.Location = new System.Drawing.Point(188, 111);
            this.decode_button.Name = "decode_button";
            this.decode_button.Size = new System.Drawing.Size(74, 20);
            this.decode_button.TabIndex = 25;
            this.decode_button.Text = "decode";
            this.decode_button.UseVisualStyleBackColor = true;
            this.decode_button.Click += new System.EventHandler(this.decode_button_Click);
            // 
            // initSet_groupBox
            // 
            this.initSet_groupBox.Controls.Add(this.ticksPerRound_textBox);
            this.initSet_groupBox.Controls.Add(this.MaxVel_textBox9);
            this.initSet_groupBox.Controls.Add(this.PIDrate_textBox);
            this.initSet_groupBox.Controls.Add(this.wheelDiameter_textBox);
            this.initSet_groupBox.Controls.Add(this.label22);
            this.initSet_groupBox.Controls.Add(this.label21);
            this.initSet_groupBox.Controls.Add(this.label20);
            this.initSet_groupBox.Controls.Add(this.label19);
            this.initSet_groupBox.Controls.Add(this.handshake_comboBox);
            this.initSet_groupBox.Controls.Add(this.stopbit_comboBox);
            this.initSet_groupBox.Controls.Add(this.parity_comboBox);
            this.initSet_groupBox.Controls.Add(this.portname_comboBox);
            this.initSet_groupBox.Controls.Add(this.label6);
            this.initSet_groupBox.Controls.Add(this.exit_button);
            this.initSet_groupBox.Controls.Add(this.label5);
            this.initSet_groupBox.Controls.Add(this.init_button);
            this.initSet_groupBox.Controls.Add(this.label4);
            this.initSet_groupBox.Controls.Add(this.label3);
            this.initSet_groupBox.Controls.Add(this.label2);
            this.initSet_groupBox.Controls.Add(this.label1);
            this.initSet_groupBox.Controls.Add(this.baudrate_textBox);
            this.initSet_groupBox.Controls.Add(this.databits_textBox);
            this.initSet_groupBox.Location = new System.Drawing.Point(3, 3);
            this.initSet_groupBox.Name = "initSet_groupBox";
            this.initSet_groupBox.Size = new System.Drawing.Size(268, 286);
            this.initSet_groupBox.TabIndex = 26;
            this.initSet_groupBox.TabStop = false;
            this.initSet_groupBox.Text = "初始化设置";
            // 
            // ticksPerRound_textBox
            // 
            this.ticksPerRound_textBox.Location = new System.Drawing.Point(216, 121);
            this.ticksPerRound_textBox.Name = "ticksPerRound_textBox";
            this.ticksPerRound_textBox.Size = new System.Drawing.Size(46, 21);
            this.ticksPerRound_textBox.TabIndex = 32;
            // 
            // MaxVel_textBox9
            // 
            this.MaxVel_textBox9.Location = new System.Drawing.Point(216, 152);
            this.MaxVel_textBox9.Name = "MaxVel_textBox9";
            this.MaxVel_textBox9.Size = new System.Drawing.Size(46, 21);
            this.MaxVel_textBox9.TabIndex = 31;
            // 
            // PIDrate_textBox
            // 
            this.PIDrate_textBox.Location = new System.Drawing.Point(94, 152);
            this.PIDrate_textBox.Name = "PIDrate_textBox";
            this.PIDrate_textBox.Size = new System.Drawing.Size(46, 21);
            this.PIDrate_textBox.TabIndex = 30;
            // 
            // wheelDiameter_textBox
            // 
            this.wheelDiameter_textBox.Location = new System.Drawing.Point(94, 121);
            this.wheelDiameter_textBox.Name = "wheelDiameter_textBox";
            this.wheelDiameter_textBox.Size = new System.Drawing.Size(46, 21);
            this.wheelDiameter_textBox.TabIndex = 29;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(8, 124);
            this.label22.Name = "label22";
            this.label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 28;
            this.label22.Text = "轮径：";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(146, 124);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 12);
            this.label21.TabIndex = 27;
            this.label21.Text = "单圈脉冲数：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 155);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 12);
            this.label20.TabIndex = 26;
            this.label20.Text = "PID调节频率：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(146, 155);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "最大速度：";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // velControl_groupBox
            // 
            this.velControl_groupBox.Controls.Add(this.clearEncoderButton);
            this.velControl_groupBox.Controls.Add(this.label18);
            this.velControl_groupBox.Controls.Add(this.label17);
            this.velControl_groupBox.Controls.Add(this.label16);
            this.velControl_groupBox.Controls.Add(this.label15);
            this.velControl_groupBox.Controls.Add(this.reset_button);
            this.velControl_groupBox.Controls.Add(this.goBack_button);
            this.velControl_groupBox.Controls.Add(this.goAhead_button);
            this.velControl_groupBox.Controls.Add(this.goLeft_button);
            this.velControl_groupBox.Controls.Add(this.goRight_button);
            this.velControl_groupBox.Controls.Add(this.sendSpeed_button);
            this.velControl_groupBox.Controls.Add(this.RSpeed_textBox);
            this.velControl_groupBox.Controls.Add(this.LSpeed_textBox);
            this.velControl_groupBox.Controls.Add(this.RDistanceLabel);
            this.velControl_groupBox.Controls.Add(this.LDistanceLabel);
            this.velControl_groupBox.Controls.Add(this.label9);
            this.velControl_groupBox.Controls.Add(this.label8);
            this.velControl_groupBox.Location = new System.Drawing.Point(328, 19);
            this.velControl_groupBox.Name = "velControl_groupBox";
            this.velControl_groupBox.Size = new System.Drawing.Size(265, 270);
            this.velControl_groupBox.TabIndex = 27;
            this.velControl_groupBox.TabStop = false;
            this.velControl_groupBox.Text = "运动控制";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(146, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 15;
            this.label18.Text = "里程/m";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(146, 42);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 14;
            this.label17.Text = "速度：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 42);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 13;
            this.label16.Text = "速度：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 66);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 12;
            this.label15.Text = "里程/m";
            // 
            // reset_button
            // 
            this.reset_button.Location = new System.Drawing.Point(6, 117);
            this.reset_button.Name = "reset_button";
            this.reset_button.Size = new System.Drawing.Size(71, 23);
            this.reset_button.TabIndex = 11;
            this.reset_button.Text = "reset";
            this.reset_button.UseVisualStyleBackColor = true;
            this.reset_button.Click += new System.EventHandler(this.reset_button_Click);
            // 
            // goBack_button
            // 
            this.goBack_button.AllowDrop = true;
            this.goBack_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.goBack_button.Cursor = System.Windows.Forms.Cursors.PanSouth;
            this.goBack_button.Location = new System.Drawing.Point(116, 213);
            this.goBack_button.Name = "goBack_button";
            this.goBack_button.Size = new System.Drawing.Size(26, 23);
            this.goBack_button.TabIndex = 10;
            this.goBack_button.Text = "后";
            this.goBack_button.UseVisualStyleBackColor = true;
            this.goBack_button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.goBack_button_MouseDown);
            this.goBack_button.MouseUp += new System.Windows.Forms.MouseEventHandler(this.goBack_button_MouseUp);
            // 
            // goAhead_button
            // 
            this.goAhead_button.AllowDrop = true;
            this.goAhead_button.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.upwards;
            this.goAhead_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.goAhead_button.Cursor = System.Windows.Forms.Cursors.PanNorth;
            this.goAhead_button.Location = new System.Drawing.Point(116, 155);
            this.goAhead_button.Name = "goAhead_button";
            this.goAhead_button.Size = new System.Drawing.Size(26, 23);
            this.goAhead_button.TabIndex = 9;
            this.goAhead_button.Text = "前";
            this.goAhead_button.UseVisualStyleBackColor = true;
            this.goAhead_button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.goAhead_button_MouseDown);
            this.goAhead_button.MouseUp += new System.Windows.Forms.MouseEventHandler(this.goAhead_button_MouseUp);
            // 
            // goLeft_button
            // 
            this.goLeft_button.AllowDrop = true;
            this.goLeft_button.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.upwards;
            this.goLeft_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.goLeft_button.Cursor = System.Windows.Forms.Cursors.PanWest;
            this.goLeft_button.Location = new System.Drawing.Point(90, 184);
            this.goLeft_button.Name = "goLeft_button";
            this.goLeft_button.Size = new System.Drawing.Size(26, 23);
            this.goLeft_button.TabIndex = 8;
            this.goLeft_button.Text = "左";
            this.goLeft_button.UseVisualStyleBackColor = true;
            this.goLeft_button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.goLeft_button_MouseDown);
            this.goLeft_button.MouseUp += new System.Windows.Forms.MouseEventHandler(this.goLeft_button_MouseUp);
            // 
            // goRight_button
            // 
            this.goRight_button.AllowDrop = true;
            this.goRight_button.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.upwards;
            this.goRight_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.goRight_button.Cursor = System.Windows.Forms.Cursors.PanEast;
            this.goRight_button.Location = new System.Drawing.Point(144, 184);
            this.goRight_button.Name = "goRight_button";
            this.goRight_button.Size = new System.Drawing.Size(26, 23);
            this.goRight_button.TabIndex = 7;
            this.goRight_button.Text = "右";
            this.goRight_button.UseVisualStyleBackColor = true;
            this.goRight_button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.goRight_MouseDown);
            this.goRight_button.MouseUp += new System.Windows.Forms.MouseEventHandler(this.goRight__MouseUp);
            // 
            // sendSpeed_button
            // 
            this.sendSpeed_button.Location = new System.Drawing.Point(188, 117);
            this.sendSpeed_button.Name = "sendSpeed_button";
            this.sendSpeed_button.Size = new System.Drawing.Size(71, 23);
            this.sendSpeed_button.TabIndex = 6;
            this.sendSpeed_button.Text = "发送命令";
            this.sendSpeed_button.UseVisualStyleBackColor = true;
            this.sendSpeed_button.Click += new System.EventHandler(this.sendSpeed_button_Click);
            // 
            // RSpeed_textBox
            // 
            this.RSpeed_textBox.Location = new System.Drawing.Point(190, 39);
            this.RSpeed_textBox.Name = "RSpeed_textBox";
            this.RSpeed_textBox.Size = new System.Drawing.Size(42, 21);
            this.RSpeed_textBox.TabIndex = 5;
            // 
            // LSpeed_textBox
            // 
            this.LSpeed_textBox.Location = new System.Drawing.Point(56, 37);
            this.LSpeed_textBox.Name = "LSpeed_textBox";
            this.LSpeed_textBox.Size = new System.Drawing.Size(42, 21);
            this.LSpeed_textBox.TabIndex = 4;
            // 
            // RDistanceLabel
            // 
            this.RDistanceLabel.AutoSize = true;
            this.RDistanceLabel.Location = new System.Drawing.Point(193, 66);
            this.RDistanceLabel.Name = "RDistanceLabel";
            this.RDistanceLabel.Size = new System.Drawing.Size(23, 12);
            this.RDistanceLabel.TabIndex = 3;
            this.RDistanceLabel.Text = "NaN";
            // 
            // LDistanceLabel
            // 
            this.LDistanceLabel.AutoSize = true;
            this.LDistanceLabel.Location = new System.Drawing.Point(56, 66);
            this.LDistanceLabel.Name = "LDistanceLabel";
            this.LDistanceLabel.Size = new System.Drawing.Size(23, 12);
            this.LDistanceLabel.TabIndex = 2;
            this.LDistanceLabel.Text = "NaN";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(146, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "右轮：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "左轮：";
            // 
            // statusWatch_groupBox
            // 
            this.statusWatch_groupBox.Controls.Add(this.batteryReq_button);
            this.statusWatch_groupBox.Controls.Add(this.label14);
            this.statusWatch_groupBox.Controls.Add(this.label13);
            this.statusWatch_groupBox.Controls.Add(this.battery_label);
            this.statusWatch_groupBox.Controls.Add(this.label7);
            this.statusWatch_groupBox.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.statusWatch_groupBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.statusWatch_groupBox.Location = new System.Drawing.Point(3, 487);
            this.statusWatch_groupBox.Name = "statusWatch_groupBox";
            this.statusWatch_groupBox.Size = new System.Drawing.Size(619, 34);
            this.statusWatch_groupBox.TabIndex = 28;
            this.statusWatch_groupBox.TabStop = false;
            this.statusWatch_groupBox.Text = "状态跟踪";
            // 
            // batteryReq_button
            // 
            this.batteryReq_button.Location = new System.Drawing.Point(161, 11);
            this.batteryReq_button.Name = "batteryReq_button";
            this.batteryReq_button.Size = new System.Drawing.Size(47, 20);
            this.batteryReq_button.TabIndex = 4;
            this.batteryReq_button.Text = "获取";
            this.batteryReq_button.UseVisualStyleBackColor = true;
            this.batteryReq_button.Click += new System.EventHandler(this.batteryReq_button_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(300, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "状态信息：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(370, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(220, 12);
            this.label13.TabIndex = 3;
            // 
            // battery_label
            // 
            this.battery_label.AutoSize = true;
            this.battery_label.Location = new System.Drawing.Point(78, 17);
            this.battery_label.Name = "battery_label";
            this.battery_label.Size = new System.Drawing.Size(23, 12);
            this.battery_label.TabIndex = 1;
            this.battery_label.Text = "NaN";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "电池电量：";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // dataWatch_groupBox
            // 
            this.dataWatch_groupBox.Controls.Add(this.clearText_button);
            this.dataWatch_groupBox.Controls.Add(this.sendData_button);
            this.dataWatch_groupBox.Controls.Add(this.receive_textBox);
            this.dataWatch_groupBox.Controls.Add(this.decode_button);
            this.dataWatch_groupBox.Controls.Add(this.send_textBox);
            this.dataWatch_groupBox.Location = new System.Drawing.Point(3, 323);
            this.dataWatch_groupBox.Name = "dataWatch_groupBox";
            this.dataWatch_groupBox.Size = new System.Drawing.Size(612, 147);
            this.dataWatch_groupBox.TabIndex = 29;
            this.dataWatch_groupBox.TabStop = false;
            this.dataWatch_groupBox.Text = "数据观察";
            // 
            // clearEncoderButton
            // 
            this.clearEncoderButton.Location = new System.Drawing.Point(90, 117);
            this.clearEncoderButton.Name = "clearEncoderButton";
            this.clearEncoderButton.Size = new System.Drawing.Size(80, 23);
            this.clearEncoderButton.TabIndex = 16;
            this.clearEncoderButton.Text = "编码器清零";
            this.clearEncoderButton.UseVisualStyleBackColor = true;
            this.clearEncoderButton.Click += new System.EventHandler(this.clearEncoderButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 533);
            this.Controls.Add(this.dataWatch_groupBox);
            this.Controls.Add(this.statusWatch_groupBox);
            this.Controls.Add(this.velControl_groupBox);
            this.Controls.Add(this.initSet_groupBox);
            this.Name = "Form1";
            this.Text = "Autolabor Pro Debugging Tool ";
            this.initSet_groupBox.ResumeLayout(false);
            this.initSet_groupBox.PerformLayout();
            this.velControl_groupBox.ResumeLayout(false);
            this.velControl_groupBox.PerformLayout();
            this.statusWatch_groupBox.ResumeLayout(false);
            this.statusWatch_groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.dataWatch_groupBox.ResumeLayout(false);
            this.dataWatch_groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox receive_textBox;
        private System.Windows.Forms.Button sendData_button;
        private System.Windows.Forms.Button init_button;
        private System.Windows.Forms.TextBox databits_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox send_textBox;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.ComboBox portname_comboBox;
        private System.Windows.Forms.ComboBox parity_comboBox;
        private System.Windows.Forms.ComboBox stopbit_comboBox;
        private System.Windows.Forms.ComboBox handshake_comboBox;
        private TextBox baudrate_textBox;
        private Button clearText_button;
        private Button decode_button;
        private GroupBox initSet_groupBox;
        private GroupBox velControl_groupBox;
        private Label RDistanceLabel;
        private Label LDistanceLabel;
        private Label label9;
        private Label label8;
        private GroupBox statusWatch_groupBox;
        private Label label13;
        private Label battery_label;
        private Label label7;
        private ErrorProvider errorProvider1;
        private SerialPort serialPort1;
        private Label label14;
        private Button batteryReq_button;
        private TextBox RSpeed_textBox;
        private TextBox LSpeed_textBox;
        private Button sendSpeed_button;
        private Button goRight_button;
        private GroupBox dataWatch_groupBox;
        private Button goBack_button;
        private Button goAhead_button;
        private Button goLeft_button;
        private Button reset_button;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private TextBox ticksPerRound_textBox;
        private TextBox MaxVel_textBox9;
        private TextBox PIDrate_textBox;
        private TextBox wheelDiameter_textBox;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Button clearEncoderButton;
    }
}

