﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class ThreadHelperClass
    {
        delegate void SetTextCallback(Form f, Control ctrl, string text);
        delegate string GetTextCallBack(Form f, Control ctrl, string text);
        /// <summary>
        /// Set text property of various controls
        /// </summary>
        /// <param name="form">The calling form</param>
        /// <param name="ctrl"></param>
        /// <param name="text"></param>
        public static void setText(Form form, Control ctrl, string text)
        {
            // InvokeRequired required compares the thread ID of the 
            // calling thread to the thread ID of the creating thread. 
            // If these threads are different, it returns true. 
            if (ctrl.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(setText);
                form.Invoke(d, new object[] { form, ctrl, text });
            }
            else
            {
                //ctrl.Text = text;
                ctrl.Text = text;
            }
        }

        public static void SetAppendText(Form form, Control ctrl, string text)
        {
            // InvokeRequired required compares the thread ID of the 
            // calling thread to the thread ID of the creating thread. 
            // If these threads are different, it returns true. 
            if (ctrl.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetAppendText);
                form.Invoke(d, new object[] { form, ctrl, text });
            }
            else
            {
                //ctrl.Text = text;
                ctrl.Text += text + ' ' + Environment.NewLine;
            }
        }

        public static string GetText(Form form, Control ctrl, string text)
        {
            if (ctrl.InvokeRequired)
            {
                GetTextCallBack d = new GetTextCallBack(GetText);
                form.Invoke(d, new object[] { form, ctrl, text });
            }
            else
            {
                text = ctrl.Text;
            }
            return text;
        }
    }
}
