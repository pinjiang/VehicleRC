﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; //memory stream
using System.IO.Ports;//serial port
using System.Threading;
using System.Data.SqlTypes;//bindata
using APSpecified;
using System.Diagnostics;


namespace WindowsFormsApplication1
{
    
    
    public partial class Form1 : Form
    {
        static bool _continue;
        public APSerialPort newsp;
        Thread readThread ;
       
         
        public Form1()
        {
            InitializeComponent();
        }

        //
        //initial
        //
        private void init_button_Click(object sender, EventArgs e)
        {
           

            newsp = new APSerialPort(GetText(portname_comboBox));

            //wheelDiameter = double.Parse(GetText(wheelDiameter_textBox));
            //encoderResolution = int.Parse(GetText(ticksPerRound_textBox));
            //PIDRATE = int.Parse(GetText(PIDrate_textBox));
            //maxVelocity = double.Parse(GetText(MaxVel_textBox9));
            APCommand.velTransformer = new APVelTransform(GetText(wheelDiameter_textBox), GetText(ticksPerRound_textBox), GetText(PIDrate_textBox), GetText(MaxVel_textBox9));
            newsp.openPort();
            ThreadStart threadStartShow = new ThreadStart(showThem);
            readThread = new Thread(threadStartShow);
            readThread.Start();
            //这会开启另一个线程
            newsp.controlStart();
           
           
        }

        //封装的跨线程修改UI的函数，使调用形式更简洁
        string GetText(Control ctrl)
        {
            string getText = ThreadHelperClass.GetText(this, ctrl, ctrl.Text.ToString());
            return getText;
        }

        public void showThem()
        {
            //或许最好别while(true),而是while(continue)
            while (true)
            {
                
                string toshow;

                //一有数据就立即解析
                if (newsp.dataStorer.Count != 0)
                {
                    System.Console.WriteLine("dataStorer大小：" + newsp.dataStorer.Count);
                   
                    bool isDone = newsp.decodeExecute();
                    
                }

                //展示发过来的数据
                while (newsp.showText.Count != 0)
                {
                    System.Console.WriteLine("showText大小：" + newsp.showText.Count);
                    ThreadHelperClass.SetAppendText(this, receive_textBox, newsp.showText[0]);
                    newsp.showText.RemoveAt(0);
                }

                //以后改成newsp的成员为一个AMcommand
                //展示电池电量
                if(APCommand.textBattery.Count !=0 )
                {
                    System.Console.WriteLine("textBattery大小：" + APCommand.textBattery.Count);
                    toshow =  APCommand.textBattery[0];
                    ThreadHelperClass.setText(this, battery_label, toshow);
                    APCommand.textBattery.RemoveAt(0);
                }

                //展示错误状态信息
                if(APCommand .textStatus.Count   !=0)
                {
                    //一发现有不对的状态，马上reset
                    newsp.reqReset();
                    System.Console.WriteLine("textStatus大小：" + APCommand.textStatus.Count);
                    toshow = APCommand.textStatus[0];
                    //不记得是哪个label了。。先占用一下label13;
                    ThreadHelperClass.setText(this,label13,toshow);
                }

                //展示reset操作的结果,和错误状态信息共享了一个label，这样是不是不太好？
                //维护记录：2018/01/24：这里把if改成while，解决了解析好的数据展示不及时的问题
                while(APCommand.textIsResetOK .Count!=0)
                {
                    System.Console.WriteLine("textIsResetOK大小：" + APCommand.textIsResetOK.Count);
                    toshow = "重置结果：(True:成功；False：失败)"+APCommand.textIsResetOK[0];
                    ThreadHelperClass.setText(this,label13,toshow);
                    APCommand.textIsResetOK.RemoveAt(0);
                }

                //展示清除编码器操作的结果
                if(APCommand .textIsClearEncoderOK.Count!=0)
                {
                    System.Console.WriteLine("textIsClearEncoderOK大小：" + APCommand.textIsClearEncoderOK.Count);
                    toshow = "清除编码器结果：(True:成功；False：失败)" + APCommand.textIsClearEncoderOK[0];
                    ThreadHelperClass.setText(this, label13, toshow);
                    APCommand.textIsClearEncoderOK.RemoveAt(0);
                }

                //展示编码器计数或直接展示已行驶的距离？
                if(APCommand.textEncoderCount .Count!=0)
                {
                    System.Console.WriteLine("textEncoderCount大小：" + APCommand.textEncoderCount.Count);
                    toshow = APCommand.textEncoderCount[0][0];
                    ThreadHelperClass.setText(this,LDistanceLabel, toshow);
                    toshow = APCommand.textEncoderCount[0][1];
                    ThreadHelperClass.setText(this, RDistanceLabel, toshow);
                    APCommand.textEncoderCount.RemoveAt(0);

                }
                
            }
        }
       
       
        
       

        //
        //exit
        //
        private void exit_button_Click(object sender, EventArgs e)
        {
           
            Application.Exit();
        }

        //
        //send
        //
        private void sendData_button_Click(object sender, EventArgs e)
        {
            
            //_serialPort.WriteLine(ThreadHelperClass.GetText(this, textBox2, textBox2.Text.ToString()));
            string fromTxtBox = ThreadHelperClass.GetText(this, send_textBox, send_textBox.Text.ToString());
            byte[] tosend = SpecialMethod.StringToByteArray(fromTxtBox);
            newsp.sendBytes(tosend);
           
        }

        //
        //clear
        //
        private void clearText_button_Click(object sender, EventArgs e)
        {
            this.receive_textBox.Text = "";
        }

        //
        //close the serial port
        //
        private void closePort_button_Click(object sender, EventArgs e)
        {
            newsp.closePort();
            
        }

        //
        //解析
        //
        private void decode_button_Click(object sender, EventArgs e)
        {
            

           newsp.decodeExecute();

            
        }

        
      


       

        //获取电量信息
        private void batteryReq_button_Click(object sender, EventArgs e)
        {

            newsp.reqBattery();

        }

        

        //发送速度指令
        private void sendSpeed_button_Click(object sender, EventArgs e)
        {
            string LSpeedstr = ThreadHelperClass.GetText(this, LSpeed_textBox, this.Text);
            short LSpeed = short.Parse(LSpeedstr);
           
            string RSpeedstr = ThreadHelperClass.GetText(this, RSpeed_textBox, this.Text);
            short RSpeed = short.Parse(RSpeedstr);

            newsp.reqWheelSpeed(LSpeed, RSpeed);
        }



        private void goRight__MouseUp(object sender, MouseEventArgs e)
        {
            
            newsp.wheelStop();
           
        }

        private void goRight_MouseDown(object sender, MouseEventArgs e)
        {
            
            newsp.goRight();
           
         
        }

       

        private void goBack_button_MouseDown(object sender, MouseEventArgs e)
        {
            
            newsp.goBack();
        }

        private void goBack_button_MouseUp(object sender, MouseEventArgs e)
        {
            
            newsp.wheelStop();
            
        }

        private void goLeft_button_MouseDown(object sender, MouseEventArgs e)
        {
           
            newsp.goLeft();
        }

        private void goLeft_button_MouseUp(object sender, MouseEventArgs e)
        {
            
            newsp.wheelStop();
            
        }

        

        private void goAhead_button_MouseDown(object sender, MouseEventArgs e)
        {
           
            newsp.goAhead();
        }

        private void goAhead_button_MouseUp(object sender, MouseEventArgs e)
        {
            
            newsp.wheelStop();
            
        }

        private void reset_button_Click(object sender, EventArgs e)
        {
            newsp.reqReset();
        }

        private void clearEncoderButton_Click(object sender, EventArgs e)
        {
            newsp.reqClearEncoder();
        }

       

    }

    
}
