﻿/********************************************************************************

** 作者： 王丹

** 创始时间：2017-12-8

** 描述：根据本公司小车产品适用的运动模型，进行相应参数的运算的类。本类的对象作为AMcommand的一个成员，在AMcommand对象中进行调用。

*********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APSpecified
{
    //速度计算的公式和方法
    public class APVelTransform
    {
        ///

        ///属性说明

        ///
        ///private double wheelDiameter 车轮直径，单位：米
        ///private int encoderResolution 编码器的脉冲数，可以理解为编码器计数
        ///private int PIDRATE PID调节PWM值的频率
        ///private int maxVelCmd 经过换算的最大速度对应的整数，当给出的速度大于最大速度，指令中发送的参数将是maxVelCmd
        ///
        //data fields
        //默认AP1物理参数
        private double defaultDiameter = 0.25;
        private int defaultPIDRate = 50;
        private int defaultEncoderResolution = 1600;
        private double defaultMaxVel = 0.6;

        private double wheelDiameter { get; set; }

        private int encoderResolution { get; set; }

        private int PIDRATE { get; set; }

        private double velocity { get; set; }

        private double maxVelocity { get; set; }

        private int maxVelCmd { get; set; }

        private int velCmd { get; set; }

        public APVelTransform()
        {

        }

        /// <summary>
        /// 以原始的对应类型的数据，初始化“速度参数计算器”
        /// </summary>
        /// <param name="wheelDiameter">轮子直径</param>
        /// <param name="encoderResolution">编码器转一圈产生的脉冲数</param>
        /// <param name="PIDRATE">PID调节PWM值的频率</param>
        /// <param name="maxVelocity">限定的最大速度。不同产品最大速度不同</param>
        public APVelTransform(double wheelDiameter, int encoderResolution, int PIDRATE, double maxVelocity)
        {
            this.wheelDiameter = setDiameter(wheelDiameter.ToString());
            this.encoderResolution = setEncoderResolution(encoderResolution.ToString());
            this.PIDRATE = setPIDRate(PIDRATE.ToString());
            this.maxVelocity = setMaxVel(maxVelocity.ToString());
        }


        /// <summary>
        /// 直接由输入框获取参数适用的构造器
        /// </summary>
        /// <param name="wheelDiameter">轮子直径</param>
        /// <param name="encoderResolution">编码器转一圈产生的脉冲数</param>
        /// <param name="PIDRATE">PID调节PWM值的频率</param>
        /// <param name="maxVelocity">限定的最大速度。不同产品最大速度不同</param>
        public APVelTransform(string wheelDiameter, string encoderResolution, string PIDRATE, string maxVelocity)
        {
            this.wheelDiameter = setDiameter(wheelDiameter);
            this.encoderResolution = setEncoderResolution(encoderResolution);
            this.PIDRATE = setPIDRate(PIDRATE);
            this.maxVelocity = setMaxVel(maxVelocity);
        }

        ///
        ///说明：安全的速度计算参数设置，如果用户没有输入或者输入了非法的值，将会把defaultDiameter赋值给diameter。为统一，均接受string类型的参数
        ///
        ///返回值：可以赋值给AMtransform的diameter成员的double类型
        ///
        public double setDiameter(string diameter)
        {
            if (diameter == "")
            {
                diameter = defaultDiameter.ToString();
            }

            return double.Parse(diameter);
        }

        ///
        ///说明：安全的速度计算参数设置，如果用户没有输入或者输入了非法的值，将会把defaultEncoderResolution赋值给encoderResolution。为统一，均接受string类型的参数
        ///
        ///返回值：可以赋值给AMtransform的encoderResolution成员的int类型
        ///
        public int setEncoderResolution(string encoderResolution)
        {
            if (encoderResolution == "")
            {
                encoderResolution = defaultEncoderResolution.ToString();
            }

            return int.Parse(encoderResolution);
        }

        ///
        ///说明：安全的速度计算参数设置，如果用户没有输入或者输入了非法的值，将会把defaultPIDRate赋值给PIDRate
        ///
        ///返回值：可以赋值给AMtransform的PIDRate成员的int类型
        ///
        public int setPIDRate(string PIDRate)
        {
            if (PIDRate == "")
            {
                PIDRate = defaultPIDRate.ToString();
            }

            return int.Parse(PIDRate);
        }

        ///
        ///说明：安全的速度计算参数设置，如果用户没有输入或者输入了非法的值，将会把defaultMaxVel赋值给maxVel
        ///
        ///返回值：可以赋值给AMtransform的PIDRate成员的double类型
        ///
        public double setMaxVel(string maxVel)
        {
            if (maxVel == "")
            {
                maxVel = defaultMaxVel.ToString();
            }

            return double.Parse(maxVel);
        }




        //车轮转动一圈，移动的距离
        public double distanceOneAround()
        {
            return wheelDiameter * 3.1415936;
        }



        //车轮转动一圈，编码器产生的脉冲数
        public double wheelEncoderResolution()
        {
            return encoderResolution;
        }

        //AP1每移动1米产生脉冲数（编码器的计数）
        public double ticksPerMeter()
        {
            //到最后一步再四舍五入
            if (this.distanceOneAround() > 0)
                return encoderResolution / this.distanceOneAround();
            else
            {
                //咋办？
                //throw exception?
                return 0.0;
            }

        }

        //指令的参数计算方法
        public int velocityCommands()
        {
            //用户发送的速度超过最大速度，将按最大速度行进
            if (velocity < maxVelocity)
            {
                if (PIDRATE != 0)
                {
                    double cmdCode = velocity * this.ticksPerMeter() / PIDRATE;

                    velCmd = (int)Math.Round(cmdCode, 0);

                    return velCmd;
                }
                else
                {
                    //throw exception?
                    return -1;

                }


            }
            else
                return maxVelCmd;

        }




    }
}
