﻿/********************************************************************************

** 作者： 王丹

** 创始时间：2017-12-8

** 描述：根据本公司小车实现的串口通讯类，封装了C# SerialPort类，以完成数据接收、发送与解析，是与UI线程联系最紧密的类

*********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Timers;

namespace APSpecified
{
    public class APSerialPort
    {
        ///

        ///属性说明

        /// 
        ///public static bool isContinue 标识是否继续运动控制（发送速度指令）
        ///private static object locker对象锁，主要用于对List<byte> dataStorer的锁定，以防其他线程进行不安全的更改
        ///private short defaultRSpeed = 8; 默认的右轮轮速
        ///private short defaultLSpeed = 8; 默认的左轮轮速
        ///
        static SerialPort serialPort;

        public APCommand command = new APCommand();
        public static bool isContinue = false;

        private static object locker = new Object();

        //需要特别设置RtsEnable,DtrEnable = true吗？
        //_serialPort.RtsEnable = true;
        //_serialPort.DtrEnable = true;
        private int defaultReadTimeout = 5000;
        private int defaultWriteTimeout = 5000;
        private short defaultRSpeed = 4;
        private short defaultLSpeed = 4;
        private short RWspeed = 0;
        private short LWspeed = 0;


        //这两个是不是应该设为private？？
        public List<byte> dataStorer = new List<byte>();
        public List<string> showText = new List<string>();



        string defaultPortName = "COM1";
        string defaultPortBaudRate = "115200";
        string defaultPortParity = "None";//"Parity.None"
        string defaultPortDataBits = "8";
        string defaultPortStopBits = "One";//"StopBits.One"
        string defaultPortHandshake = "None";//"Handshake.None"

        //constructors
        public APSerialPort()
        {

        }

        public APSerialPort(string portname)
        {
            serialPort = new SerialPort();
            serialPort.PortName = setPortName(portname);
            serialPort.BaudRate = setPortBaudRate(defaultPortBaudRate);
            serialPort.Parity = setPortParity(defaultPortParity);
            serialPort.DataBits = setPortDataBits(defaultPortDataBits);
            serialPort.StopBits = setPortStopBits(defaultPortStopBits);
            serialPort.Handshake = setPortHandshake(defaultPortHandshake);
            serialPort.ReadTimeout = defaultReadTimeout;
            serialPort.WriteTimeout = defaultWriteTimeout;


        }
        public APSerialPort(string COMname, string baudrate, string parity,
            string dataBits, string stopBits, string handshake)
        {
            serialPort = new SerialPort();
            serialPort.PortName = setPortName(COMname);
            serialPort.BaudRate = setPortBaudRate(baudrate);
            serialPort.Parity = setPortParity(parity);
            serialPort.DataBits = setPortDataBits(dataBits);
            serialPort.StopBits = setPortStopBits(stopBits);
            serialPort.Handshake = setPortHandshake(handshake);
            serialPort.ReadTimeout = defaultReadTimeout;
            serialPort.WriteTimeout = defaultWriteTimeout;

        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortName赋值给PortName
        ///
        ///返回值：可以赋值给serialPort.PortName的string类型
        ///
        public string setPortName(string portName)
        {

            if (portName == "" || !(portName.ToLower()).StartsWith("com"))
            {
                portName = defaultPortName;
            }
            return portName;
        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortBaudRate赋值给BaudRate
        ///
        ///返回值：可以赋值给serialPort.BaudRate的string类型
        ///

        public int setPortBaudRate(string baudRate)
        {
            if (baudRate == "")
            {
                baudRate = defaultPortBaudRate.ToString();
            }

            return int.Parse(baudRate);
        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortParity赋值给Parity
        ///
        ///返回值：可以赋值给serialPort.Parity的string类型
        ///
        public Parity setPortParity(string parity)
        {
            if (parity == "")
            {
                parity = defaultPortParity.ToString();
            }

            return (Parity)Enum.Parse(typeof(Parity), parity, true);
        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortDataBits赋值给DataBits
        ///
        ///返回值：可以赋值给serialPort.DataBits的string类型
        ///
        public int setPortDataBits(string dataBits)
        {
            if (dataBits == "")
            {
                dataBits = defaultPortDataBits.ToString();
            }

            return int.Parse(dataBits.ToUpperInvariant());
        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortStopBits赋值给StopBits
        ///
        ///返回值：可以赋值给serialPort.StopBits的string类型
        ///
        public StopBits setPortStopBits(string stopBits)
        {
            if (stopBits == "")
            {
                stopBits = defaultPortStopBits.ToString();
            }

            return (StopBits)Enum.Parse(typeof(StopBits), stopBits, true);
        }

        ///
        ///说明：安全的serial port属性设置，如果用户没有输入或者输入了非法的值，将会把defaultPortHandshake赋值给Handshake
        ///
        ///返回值：可以赋值给serialPort.Handshake的string类型
        ///
        public Handshake setPortHandshake(string handshake)
        {
            if (handshake == "")
            {
                handshake = defaultPortHandshake.ToString();
            }

            return (Handshake)Enum.Parse(typeof(Handshake), handshake, true);
        }

        //AMvel_transform对象实例属性设置

        //getter,setter
        public List<string> getText()
        {
            return showText;
        }

        public List<byte> getStoredData()
        {
            return dataStorer;
        }

        public void setReadTimeOut(int readTimeout)
        {
            if (readTimeout > 0)
            {
                serialPort.ReadTimeout = readTimeout;
            }

        }

        public void setWriteTimeout(int writeTimeout)
        {
            if (writeTimeout > 0)
            {
                serialPort.WriteTimeout = writeTimeout;
            }
        }

        //actions

        ///
        ///说明：打开串口，并加载委托事件——_serialPort_DataReceived()方法。一旦数据缓存区接收到数据，即触发该方法_serialPort_DataReceived()
        ///

        public void openPort()
        {
            serialPort.Open();
            serialPort.DataReceived += new SerialDataReceivedEventHandler(_serialPort_DataReceived);
        }

        //send Bytes
        ///
        ///说明：//发送byte数组（即封装好的指令）
        ///
        ///<toSend>意欲发送的字节数组型的指令</toSend>
        ///
        public void sendBytes(byte[] tosend)
        {
            serialPort.Write(tosend, 0, tosend.Length);
        }

        //
        //close the serial port
        //
        public void closePort()
        {
            serialPort.Close();
        }

        ///
        ///说明：一旦接收到数据将发生的事件。可能会有timeoutException。但是这里在catch(){}中没有作出具体处理
        ///
        ///<toSend>意欲发送的字节数组型的指令</toSend>
        ///
        void _serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort port = (SerialPort)sender;
            Thread.Sleep(10);

            try
            {
                int len = port.BytesToRead;
                byte[] data = new byte[len];

                port.Read(data, 0, len);

                if (data.Length != 0)
                {

                    dataStorer.AddRange(data);
                    string ss = SpecialMethod.byteToHexStr(data);

                    showText.Add(ss);

                }
            }
            catch (TimeoutException)
            {

            }
        }
        ///
        ///说明：//用于决定是否开始前后左右控制
        ///

        public void controlStart()
        {
            ThreadStart directionThrdStart = new ThreadStart(letsGo);
            Thread directionThrd = new Thread(directionThrdStart);
            //if (isContinue == false)
            //{
            isContinue = true;

            directionThrd.Start();
            //}
            //else
            //{ }
        }

        ///
        ///说明：//用于停止控制行动的线程
        ///

        public void controlStop()
        {
            //isContinue的功能还有待商榷
            isContinue = false;

        }

        ///
        ///说明：//发送请求电量信息的指令
        ///

        public void reqBattery()
        {
            byte[] batteryReq = APCommand.batteryReq();
            serialPort.Write(batteryReq, 0, batteryReq.Length);
        }

        ///
        ///说明：//发送请求以速度行进的指令
        ///

        public void reqWheelSpeed(short LSpeed, short RSpeed)
        {

            byte[] speedReq = APCommand.setVelocity(LSpeed, RSpeed);

            serialPort.Write(speedReq, 0, speedReq.Length);

        }

        ///
        ///说明：//发送请求reset的指令
        ///

        public void reqReset()
        {
            byte[] resetReq = APCommand.resetReq();
            serialPort.Write(resetReq, 0, resetReq.Length);
        }

        ///
        ///说明：//发送请求reset的指令
        ///

        public void reqClearEncoder()
        {
            byte[] clearEncoderReq = APCommand.clearEncoderReq();
            serialPort.Write(clearEncoderReq, 0, clearEncoderReq.Length);
        }

        ///
        ///说明：//以一定速度行走，将发送指定的左右轮速度
        ///


        public void letsGo()
        {

            while (true)
            {
                if (isContinue)
                {
                    reqWheelSpeed(LWspeed, RWspeed);
                    //执行完休息200ms
                    Thread.Sleep(400);
                }
                else continue;
            }



        }

        ///
        ///说明：//修改向前走需要的左右轮速
        ///

        public void goAhead()
        {

            RWspeed = defaultRSpeed;
            LWspeed = defaultLSpeed;
            //letsGo();
        }
        ///
        ///说明：//修改向右走需要的左右轮速
        ///

        public void goRight()
        {
            RWspeed = (short)-defaultRSpeed;
            LWspeed = defaultLSpeed;


        }

        ///
        ///说明：//修改向左走需要的左右轮速
        ///

        public void goLeft()
        {

            LWspeed = (short)-defaultRSpeed;
            RWspeed = defaultLSpeed;
        }

        ///
        ///说明：//修改向后走需要的左右轮速
        ///
        public void goBack()
        {

            RWspeed = (short)-defaultRSpeed;
            LWspeed = (short)-defaultLSpeed;
        }

        ///
        ///说明：//修改使小车停止前进需要的左右轮速，即0
        ///

        public void wheelStop()
        {

            RWspeed = (short)0;
            LWspeed = (short)0;
        }

        ///
        ///说明：逐字节解析List<byte> dataStorer中的数据，解析出后进行执行对应的指令。解析后删除对应位置的数据
        ///

        public bool decodeExecute()
        {

            //其实究竟需不需要lock呢？
            //lock (dataStorer)
            //lock (locker)
            //{
            try
            {
                while (dataStorer.Count > 0)//count<0就没必要做下面的事情了
                {
                    //反正指令最长是2+1+1+1+1+8=14字节，不如一次载入14个（如果dataStorer中没有14个呢？那就有多少个，就复制多少个。取小者）
                    byte[] getstr = dataStorer.GetRange(0, 14 < dataStorer.Count ? 14 : dataStorer.Count).ToArray();
                    byte[] newCmd = APProto.findCmd(getstr);
                    if (newCmd != null && newCmd.Length != 0)//后面这个判断条件似乎是多余的
                    {
                        APProto cmdDecoded = APProto.decode(newCmd);


                        //这里最好弄个异步执行，让delegate去做UIExecuteCmd?
                        if (cmdDecoded != null)
                        {
                            //这儿会有exception吗？
                            APCommand.executeCmd(cmdDecoded);

                        }

                        //不能直接这么removed掉。剩下的字节可能跟下一条消息组成一条有效指令，所以只能把frmEnd及之前的字节去掉（而不是去掉这一行byte数组）
                        //如何remove？至少去掉newCmd.length个
                        dataStorer.RemoveRange(0, newCmd.Length);
                        //找到一条有效指令就结束，否则一直找，直到dataStorer里没数据了
                        //break;
                    }
                    else
                    {
                        //没有找到有效的指令，所以，可以考虑只丢掉第一个byte元素，以让getstr获取的数据可以后移一个
                        dataStorer.RemoveAt(0);

                    }
                }
            }
            catch (Exception e) { }
            //finally

            //}
            return true;

        }
    }
}
/*
                         * 没有找到有效指令有哪些情况？
                         * 1.给的getstr里面，没有找到header，55,AA
                         * 2.找到了55，AA,后面跟的应是length，但由此计算得到的frmEnd>=getstr.length:
                         *  (A.length<=9，但是getStr从dataStorer中截取到的数据不够 ===>dataStorer.RemoveAt(0);这样的话，有希望逐步得到有效值，而且这么做的前提是，dataStorer[0]处一定不是有用值)
                         *  (B.length过大，大于9，导致frmEnd>data.length）：
                         *      A.length字节传输错误 ===>?   
                         *      B.该55，AA被传输错误，即不是有效的header===>?
                         * 3.找到了55，AA,后面跟的应是length，但由此计算得到的checksum值不对
                        */