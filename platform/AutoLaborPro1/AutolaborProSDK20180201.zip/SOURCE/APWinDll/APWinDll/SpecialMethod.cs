﻿/********************************************************************************

** 作者： 王丹

** 创始时间：2017-12-8

** 描述：在进行指令封装与解析过程中，需要用到的数值转换的方法集合。如：intStoreToByteStore(),将int转为1个byte存储的数据。

*********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APSpecified
{
    public class SpecialMethod
    {
        //int 转byte[],且去掉高字节多余的0


        ///
        ///说明：将一个int型数字转为byte型数组，将多余的0字节去掉。如3-->0x03;256-->0x0100
        ///
        ///返回值：存储转化后的数字byte数组，用于AMproto类对象byte型成员的赋值
        ///
        public static byte[] intStoreToByteStore(int intstore)
        {
            byte[] byteTemp = System.BitConverter.GetBytes(intstore);
            List<byte> byteStore = new List<byte>(byteTemp);
            for (int i = sizeof(int) - 1; i >= 0; i--)
            {
                if (byteTemp[i] == 0x00)
                {
                    byteStore.RemoveAt(i);
                }
                else break;

            }
            byteTemp = (byte[])byteStore.ToArray();
            return byteTemp;

        }


        ///
        ///说明：//重载
        ///      如果int值小于256，只要一个字节，如果大于255，小于65535，需要两个字节。
        ///      但是根据协议，每个轮速占固定2个字节。所以使用时，int bytes取2即可。将一个int型数字转为指定长度的byte型数组，将多余的0字节去掉。如intStoreToByteStore(3,2)-->0x0003
        ///      为轮速赋值时，也可以直接使用short类型的整数
        ///
        ///返回值：存储转化后的数字byte数组，用于AMproto类对象byte型成员的赋值
        ///
        public static byte[] intStoreToByteStore(int intstore, int bytes)
        {
            if (bytes > 7 || bytes < 0)
                return null;
            else
            {
                byte[] byteTemp = System.BitConverter.GetBytes(intstore);
                List<byte> byteStore = new List<byte>(byteTemp);
                //低位在前（左），高位在后（右）
                for (int i = sizeof(int) - 1; i >= sizeof(int) - bytes; i--)
                {
                    byteStore.RemoveAt(i);
                }
                byteTemp = (byte[])byteStore.ToArray();
                return byteTemp;
            }

        }

        ///
        ///说明：将一个byte型数组存储的数字转为int。
        ///
        ///返回值：存储转化后的int值
        ///
        public static int byteStoreToIntStore(byte[] byteStore)
        {
            List<byte> byteTemp = new List<byte>(byteStore);
            for (int i = byteStore.Length; i < sizeof(int); i++)
            {
                byteTemp.Add(0x00);
            }
            int intStore = System.BitConverter.ToInt32((byte[])byteTemp.ToArray(), 0);
            return intStore;
        }



        /*** 不要用int转byte！！！！  */
        public static byte[] IntArrToByteArr(int[] intArr)
        {
            byte[] result = new byte[intArr.Length * sizeof(int)];
            Buffer.BlockCopy(intArr, 0, result, 0, result.Length);
            return result;
        }

        //byte转 int[]
        public static int[] ByteArrToIntArr(byte[] byteArr)
        {
            int[] result = new int[byteArr.Length / sizeof(int)];
            Buffer.BlockCopy(byteArr, 0, result, 0, result.Length);
            return result;
        }

        //byte 转 hex
        public static string byteToHexStr(byte[] bytes)
        {
            string returnStr = "";
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    returnStr += bytes[i].ToString("X2") + ' ';
                }
            }
            return returnStr;
        }

        //hex string -- byte
        ///
        ///说明：将一串hex字符串（string类型，但是表示16进制数）转为字面上也对应的字节数组
        ///
        ///返回值：存储转化后的数字byte数组，用于AMproto类对象byte型成员的赋值
        ///
        public static byte[] StringToByteArray(string hex)
        {
            char[] spliter = new char[4] { ' ', '-', '\n', '\r' };
            string[] toHex = hex.Split(spliter, StringSplitOptions.RemoveEmptyEntries);
            byte[] ByteArr = new byte[toHex.Length];
            for (int i = 0; i < toHex.Length; i++)
            {
                char[] ch = toHex[i].ToArray();
                ByteArr[i] = (byte)((GetHexVal(ch[0]) << 4) + GetHexVal(ch[1]));
            }
            return ByteArr;
        }

        ///
        ///取一个字符字面意义的16进制字节数。如‘0A'--->0x0A
        ///
        ///返回值：存储转化后的数字byte数组，用于AMproto类对象byte型成员的赋值
        ///
        public static int GetHexVal(char hex)
        {
            int val = (int)hex;

            return val - (val < 58 ? 48 : (val < 97 ? 55 : 87));
        }
    }
}
