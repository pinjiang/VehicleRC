﻿
/********************************************************************************

** 作者： 王丹

** 创始时间：2017-12-8

** 描述：执行指令与发送指令所需要用到的各种方法。如ExecuteCmd()等

*********************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace APSpecified
{
    //实施速度指令换算等
    public class APCommand
    {
        ///

        ///属性说明

        ///以下数据以string存储，便于展示在窗体程序界面上
        /// public static List<string> textBattery          存储接收到的电量信息
        /// public static List<string[]> textEncoderCount   存储接收到的编码器（相对）累计计数信息
        /// public static List<string> textIsClearEncoderOK 存储接收到的编码器是否成功清零信息
        /// public static List<string> textIsResetOK        存储接收到的机器是否成功被重置信息
        /// public static List<string> textStatus           存储接收到的错误状态的具体原因信息
        /// 

        //data fields

        public enum commandID : byte { wheelSpeed = 0x01, battery, reset = 0x05, clearEncoder, faultStatus = 0xff };

        public enum faultStatus : byte { lowBattery = 0x01, overECurrent, serialError, wheelStuck };

        //这是02,05,06请求指令通用的parameter：即为0x00
        protected static byte[] reqParamNull = new byte[] { 0x00 };

        public static List<string> textBattery = new List<string>();
        public static List<string[]> textEncoderCount = new List<string[]>();
        public static List<string> textIsClearEncoderOK = new List<string>();
        public static List<string> textIsResetOK = new List<string>();
        public static List<string> textStatus = new List<string>();

        public static APVelTransform velTransformer;

        //constructor
        public APCommand()
        {

        }
        ///

        /// 说明：可直接根据窗体程序中得到的string类型的数值，初始化AMcommand对象。而需要在构造器中初始化的成员只有AMvelTransform类的velTransformer对象

        ///

        /// <wheelDiameter>使用的小车的轮径。不同产品会有不同的轮径，故需要由用户输入。用户不输入时，默认使用APM1的参数。详见AMvelTransform的数据成员</wheelDiameter>

        ///<encoderResolution>编码器转一圈产生的脉冲数,用户不输入时，默认使用APM1的参数。</encoderResolution>

        ///<PIDRATE>PID调节PWM值的频率。用户不输入时，默认使用APM1的参数。</PIDRATE>

        ///<maxVelocity>最大速度。不同产品会有不同的最大速度。这个速度需要指定，由工程师实际测量得到。用户不输入时，默认使用APM1的参数。</maxVelocity>

        ///
        public APCommand(string wheelDiameter, string encoderResolution, string PIDRATE, string maxVelocity)
        {
            velTransformer = new APVelTransform(wheelDiameter, encoderResolution, PIDRATE, maxVelocity);
        }



        ///

        /// 说明：根据一个AMproto对象。得到指令中对应的内容，并存储到不同的列表中。故在流程中，得到一个有效的AMproto对象的工作，应在使用本方法之前完成

        ///

        /// <someCmd>某个非空的有效的AMproto对象。</someCmd>

        ///

        public static void executeCmd(APProto someCmd)
        {
            // AMcommand exe = new AMcommand();
            string[] retInfo;
            string info;
            if (someCmd != null)
            {
                switch (someCmd.getMsgID())
                {
                    case (byte)commandID.wheelSpeed:
                        {

                            //这里得到的应该是轮子对应编码器的计数！

                            retInfo = new string[2] { getEncoderCountL(someCmd).ToString(), getEncoderCountR(someCmd).ToString() };
                            //这里只给出累计里程。

                            int encoderCountL = int.Parse(retInfo[0]);
                            retInfo[0] = (encoderCountL / velTransformer.ticksPerMeter()).ToString();
                            int encoderCountR = int.Parse(retInfo[1]);
                            retInfo[1] = (encoderCountR / velTransformer.ticksPerMeter()).ToString();
                            textEncoderCount.Add(retInfo);
                        }
                        break;
                    case (byte)commandID.battery:
                        {
                            info = getBattery(someCmd).ToString();
                            textBattery.Add(info);
                        }
                        break;
                    case (byte)commandID.clearEncoder:
                        {
                            info = isClearEncoder(someCmd).ToString();
                            textIsClearEncoderOK.Add(info);
                        }
                        break;
                    case (byte)commandID.faultStatus:
                        {
                            info = whichFaultStatus(someCmd).ToString();
                            textStatus.Add(info);
                        }
                        break;
                    case (byte)commandID.reset:
                        {
                            info = isReset(someCmd).ToString();
                            textIsResetOK.Add(info);
                        }
                        break;
                    default:
                        info = "undefined command!";//这里处理的不好
                        break;
                }
            }

        }

        //
        //与UI交互的方法集
        //
        //测试用的指令：FF 55 AA 09 01 01 00 01 00 02 00 00 00 00 F5 55 AA CC 1A DD

        ///

        /// 说明：根据一个AMproto对象，得到byte格式存储的左轮的编码器累计计数，并转换为int类型

        ///

        /// <cmd>某个非空的有效的AMproto对象。</cmd>

        ///
        public static int getEncoderCountL(APProto cmd)
        {
            cmd.getSequence();
            //交换高低字节
            byte[] LSpeed = new byte[2] { cmd.getParam()[1], cmd.getParam()[0] };

            return SpecialMethod.byteStoreToIntStore(LSpeed);
        }
        public static int getEncoderCountR(APProto cmd)
        {
            cmd.getSequence();
            //交换高低字节
            byte[] RSpeed = new byte[2] { cmd.getParam()[3], cmd.getParam()[2] };
            return SpecialMethod.byteStoreToIntStore(RSpeed);
        }

        ///

        /// 说明：根据一个AMproto对象，得到byte格式存储的剩余电量百分比（省略百分符号%），精度为1，并转换为int类型

        ///

        /// <cmd>某个非空的有效的AMproto对象。</cmd>

        ///
        public static int getBattery(APProto cmd)
        {
            cmd.getSequence();
            byte[] battery = new byte[1] { cmd.getParam()[0] };
            return SpecialMethod.byteStoreToIntStore(battery);
        }

        ///

        /// 说明：根据一个AMproto对象，得到byte格式存储的重置操作的结果（1：成功；0：失败），并转换为int类型

        ///

        /// <cmd>某个非空的有效的AMproto对象。</cmd>

        ///
        public static bool isReset(APProto cmd)
        {
            cmd.getSequence();
            byte[] isSucceded = new byte[1] { cmd.getParam()[0] };
            if (isSucceded[0] == 0x01)
            {
                return true;
            }
            else return false;
        }

        ///

        /// 说明：根据一个AMproto对象，得到byte格式存储的清除编码器计数操作的结果（1：成功；0：失败），并转换为int类型

        ///

        /// <cmd>某个非空的有效的AMproto对象。</cmd>

        ///
        public static bool isClearEncoder(APProto cmd)
        {
            cmd.getSequence();
            byte[] isSucceded = new byte[1] { cmd.getParam()[0] };
            if (isSucceded[0] == 0x01)
            {
                return true;
            }
            else return false;
        }

        ///

        /// 说明：根据一个AMproto对象，得到byte格式存储的错误状态的原因类型（01	电池没电;02	电流过大;03	串口通信故障;04	车轮卡死），并转换为int类型
        /// default:后续可能会扩充别的状态信息

        ///

        /// <cmd>某个非空的有效的AMproto对象。</cmd>

        ///
        public static string whichFaultStatus(APProto cmd)
        {
            cmd.getSequence();
            byte[] status = new byte[1] { cmd.getParam()[0] };

            string info;
            switch (status[0])
            {
                case (byte)faultStatus.wheelStuck:
                    info = "wheel stuck";
                    break;
                case (byte)faultStatus.serialError:
                    info = "serial communication error";
                    break;
                case (byte)faultStatus.overECurrent:
                    info = "The electric current is too big";
                    break;
                case (byte)faultStatus.lowBattery:
                    info = " the battery runs out";
                    break;
                default:
                    info = "the response is wrong";
                    break;
            }
            return info;

        }

        ///**********************************************************************************************************

        /// 说明：//以下方法在调用时，sequence累加,sequence是static类型的

        ///**********************************************************************************************************

        ///

        /// 说明：  请求电量的指令的封装

        ///返回值说明：一条功能为请求电量信息的完整指令，类型为byte[]，包括校验码的生成

        ///

        public static byte[] batteryReq()
        {
            APProto.sequence++;
            //如果干脆为每类指令都写一个AMproto方法，是过分设计吗？会增加复杂性吗？

            APProto batteryReq = new APProto(2, 2, reqParamNull);

            return batteryReq.encode();
        }

        ///

        /// 说明： //请求重置

        ///返回值说明：一条功能为请求重置的完整指令，可直接写入串口并发送，类型为byte[]，包括校验码的生成

        ///


        public static byte[] resetReq()
        {
            APProto.sequence++;
            APProto resetReq = new APProto(2, 5, reqParamNull);
            return resetReq.encode();
        }

        ///

        /// 说明： //请求对编码器清零

        ///返回值说明：一条功能为请求清零编码器的完整指令，可直接写入串口并发送，类型为byte[]，包括校验码的生成

        ///

        public static byte[] clearEncoderReq()
        {
            APProto.sequence++;
            APProto clearEncoderReq = new APProto(2, 6, reqParamNull);
            return clearEncoderReq.encode();
        }

        ///

        /// 说明： //发送车轮速度指令

        ///<LWheelSpeed>左轮轮速</LWheelSpeed>

        ///<RWheelSpeed>右轮轮速</RWheelSpeed>

        ///返回值说明：一条功能指定特定速度的完整指令，可直接写入串口并发送，类型为byte[]，包括校验码的生成

        ///
        public static byte[] setVelocity(short LWheelSpeed, short RWheelSpeed)
        {
            APProto.sequence++;

            byte[] RBytes = System.BitConverter.GetBytes(RWheelSpeed);
            byte[] LBytes = System.BitConverter.GetBytes(LWheelSpeed);
            byte[] velParam = new byte[8] { LBytes[1], LBytes[0], RBytes[1], RBytes[0], 0x00, 0x00, 0x00, 0x00 };
            APProto setVelocityReq = new APProto(9, 1, velParam);
            return setVelocityReq.encode();
        }



    }
}
