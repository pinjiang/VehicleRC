﻿/********************************************************************************

** 作者： 王丹

** 创始时间：2017-12-8

** 描述：解析与封装某条指令对应的类，包括消息头等结构，并提供对应的校验、解析指令、根据对应参数封装指令的方法，如parity(),encode()等

*********************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace APSpecified
{

    //pack protocol
    public class APProto
    {
        /**data fields */

        /**dataFrame  */

        //2 bytes
        //以固定不变的“55AA”作为起始标志位，标志着一帧的开始。
        private byte[] header = new byte[2] { 0x55, 0xAA };

        //1 bytes
        //表示数据包 Payload 的长度。
        private byte length;

        //1 bytes
        //帧的序列号从0开始，范围为0~255，消息的发送端每发送一个帧将该字段的值加1，接收端可以根据该字段是否连续，判断是否有丢包的情况发生。
        //这两个，是否可以合并成一个联合变量？
        //最好是放在某个package里，把属性改为portected
        public static byte sequence = 0;
        private byte sequenceToMatch;
        //N bytes
        //Payload
        //Payload分为两部分：MsgID和PARAM。

        //01-06,FF,定长，一字节
        //指令根据msgId分类
        private byte msgID;

        //变长
        //PARAM
        private byte[] param;
        //反正还没实例化？
        //private List<byte> [] param;

        //生成指令串

        private List<byte> toCmds = new List<byte>();

        //1 bytes
        //异或（XOR）校验的方式，根据具体发送的指令生成异或校验码，校验的数据包括帧头55AA
        //Checksum
        private byte checksum;

        //Constructors
        //default
        public APProto()
        {

        }


        ///

        /// 说明：以byte类型的参数初始化一个AMproto对象

        ///<length>指令中MsgID和param的总长度（字节），即payload的字节数</length>

        ///<msgID>标志指令类型</msgID>

        ///<param name="length">消息的有效数据，如电量等</param>

        ///返回值说明：一条功能指定特定速度的完整指令，可直接写入串口并发送，类型为byte[]，包括校验码的生成

        ///
        public APProto(byte length, byte msgID, byte[] param)
        {
            this.length = length;
            //this.Sequence = Sequence;
            this.msgID = msgID;
            Buffer.BlockCopy(param, 0, this.param, 0, param.Length);
            //此处不管checksum，由Encode（）来生成校验码
        }


        ///

        /// 说明：以int类型的参数初始化一个AMproto对象

        ///
        public APProto(int length, int msgID, byte[] param)
        {

            this.length = SpecialMethod.intStoreToByteStore(length)[0];
            this.msgID = SpecialMethod.intStoreToByteStore(msgID)[0];
            this.param = new byte[length - 1];
            Buffer.BlockCopy(param, 0, this.param, 0, param.Length);
            //此处不管checksum，由Encode（）来生成校验码
        }

        /***封装*************/

        /* 设置data fields的数值 */
        //SetLength()
        private bool setLength(int len)
        {
            if (len >= 2)
            {
                length = APSpecified.SpecialMethod.intStoreToByteStore(len)[0];

                return true;
            }
            else return false;
        }

        //是不是返回int会更好？？不让别人知道我们的内容是用byte存储的
        /*public int GetLength()
        {
            
            byte[] len = new byte[]{this.Length };
            return specialMethod.byteStore_intStore (len);
        }
         * */

        public byte getLength()
        {
            return this.length;
        }
        //SetSequence()

        public bool setSequence(int seq)
        {
            if (seq >= 0 & seq < 256)
            {
                sequence = APSpecified.SpecialMethod.intStoreToByteStore(seq)[0];
                return true;
            }
            else return false;
        }

        public byte getSequence()
        {
            return sequence;
        }
        //拆解与否？
        /*生成payload:mgsID + param */
        //SetPayload()

        //SetMsgID()
        public bool setMsgID(int msgID)
        {
            if (msgID >= 0)
            {
                msgID = APSpecified.SpecialMethod.intStoreToByteStore(msgID)[0];
                return true;
            }
            else return false;
        }

        public byte getMsgID()
        {
            return msgID;
        }

        //SetParam()

        public bool setParam(byte[] parameter)
        {

            if (parameter.Length > 0)
            {

                param = (byte[])parameter.Clone();
                return true;
            }
            else return false;
        }

        public byte[] getParam()
        {

            return param;

        }


        /*parity */
        ///
        ///说明：计算校验一个字节数组的校验码Parity()。如果下标不合法，则返回0x01
        ///
        ///<param>
        ///<start>从index为start的元素开始，包括该元素</start>
        ///<end> 不包括end位置的元素</end>
        ///</param>
        ///
        ///返回值：生成的字节型的校验码
        ///
        private static byte parity(byte[] data, int start, int end)
        {
            byte check = data[start];
            if (start >= 0 & start < end & end <= data.Length)
            {
                for (int i = start + 1; i < end; i++)
                {
                    check ^= data[i];
                }
                return check;
            }
            else return 0x01;//不能直接返回data[start],因为data[start]可能刚好为0x00
        }




        ///
        ///说明： /计算某条指令的校验码是否正确，即最后一个字节和前面所有字节的异或的结果（调用parity()）是否相等，相等则该指令校验正确
        ///
        ///<tocheck>字节数组型的一条待检测校验码的指令</tocheck>
        ///
        ///返回值：传输校验码与指令的校验结果相等，则返回true，否则返回false
        ///
        public static bool isChecksumCorrect(byte[] toCheck)
        {

            byte cmdChecksum = parity(toCheck, 0, toCheck.Length - 1);
            byte checkit = toCheck[toCheck.Length - 1];
            if ((cmdChecksum ^= checkit) == 0x00)
            {
                return true;
            }

            return false;
        }






        /*根据参数封装 */
        ///
        ///说明：连接各个byte成为一个完整的串
        ///
        ///返回值：一条封装好的指令（数组），包括自动计算出的校验码
        ///
        public byte[] encode()
        {
            toCmds.AddRange(header);
            toCmds.Add(length);
            toCmds.Add(sequence);
            toCmds.Add(msgID);
            toCmds.AddRange(param);
            /*生成校验码  55 xor AA = FF*/
            byte[] checkit = toCmds.ToArray();
            checksum = parity(checkit, 0, checkit.Length - 1);
            toCmds.Add(checksum);
            return toCmds.ToArray();
        }

        /***解析***************/

        //得到数据帧的长度

        //新建一个实例对象

        //调用set方法，初始化各data fields

        /*解析消息头 */


        ///
        ///说明：在任意取出的一串字节数组中寻找一条或多条格式正确的指令
        ///
        ///返回值：一条格式正确的指令（数组），包括校验码也是正确的
        ///

        public static byte[] findCmd(byte[] data)
        {

            if (data.Length >= 7)//小于7就没必要解析了
            {
                int frmHead = -1, frmEnd = 0;

                int j = 0;
                do
                {
                    if ((0x55 ^ data[j]) == 0x00 & (0xAA ^ data[j + 1]) == 0x00) //***
                    {
                        frmHead = j;//***

                        byte[] len = new byte[1] { data[j + 2] };

                        int len_set = APSpecified.SpecialMethod.byteStoreToIntStore(len);
                        frmEnd = frmHead + 4 + len_set;
                        /**这个判断逻辑是不对的！可能后面刚好传错了，不是55，AA,那岂不是这条正确的也算不对了？
                        *if (frmEnd <data.Length && (data[frmEnd + 1] ^ 0x55) == 0x00 && (data[frmEnd + 2] ^ 0xAA) == 0x00)*/
                        if (frmEnd < data.Length)
                        {
                            //找到一条结构 可能完整 的指令了


                            //可能这样比较好：找到指令、判断指令是否有效（传输无误）分为两个函数写。后者使用委托在前者函数体内部实现
                            byte[] cmd0 = new byte[frmEnd - frmHead + 1];
                            Buffer.BlockCopy(data, frmHead, cmd0, 0, frmEnd - frmHead + 1);

                            if (isChecksumCorrect(cmd0))
                            {
                                //发现一条有效指令，可以开始解析了

                                return cmd0;
                            }
                            else
                            {

                                j++;
                                continue;

                            }

                        }
                        else
                        {
                            j++;
                            continue;

                        }
                    }
                    else  //后移一个，继续找header
                    {
                        j++;
                        continue;

                    }
                } while (j + 2 < data.Length);//最后3个字节没必要判断了

            }
            return null;
        }


        //写一个delegate试试？暂时不使用
        // delegate AMproto Decoder(byte[] toDecode);
        delegate APProto Decoder();

        public static APProto decode(byte[] toDecode)
        {
            if (toDecode.Length > 5)
            {
                APProto beenDecoded = new APProto();
                Buffer.BlockCopy(toDecode, 0, beenDecoded.header, 0, 2);
                beenDecoded.length = toDecode[2];
                //把sequence属性改为static之后，下面这一行就得改了
                //beenDecoded.Sequence = toDecode[3];
                beenDecoded.sequenceToMatch = toDecode[3];
                beenDecoded.msgID = toDecode[4];
                beenDecoded.param = new byte[toDecode.Length - 6];
                Buffer.BlockCopy(toDecode, 5, beenDecoded.param, 0, beenDecoded.param.Length);
                beenDecoded.checksum = toDecode[toDecode.Length - 1];
                return beenDecoded;
            }
            else return null;
        }


    }


}

